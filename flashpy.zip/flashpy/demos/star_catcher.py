"""STAR CATCHER -- a flashpy demo game in the spirit of a 2004 web game.

Run it::

    python -m flashpy.demos.star_catcher

Controls: mouse or LEFT/RIGHT arrows. Catch the falling stars, avoid
letting them hit the ground.

The game intentionally exercises every engine feature: gradient backgrounds,
multi-layer MovieClips (the sun's rotating rays, the player's blink cycle),
keyframe-free programmatic tweens, the easing library, bubbling mouse events
for the buttons, vector-drawn hearts via bezier paths and TextFields.
"""
from __future__ import annotations

import math
import random

import pygame

import flashpy
from flashpy import (Color, MovieClip, Sprite, Stage, TextField, TweenSpec,
                     easing)
from flashpy import sound

W, H = 550, 400
GROUND_Y = 352
SKY_TOP = (255, 196, 120)
SKY_BOTTOM = (255, 243, 219)
INK = (64, 42, 30)


def clamp(v, lo, hi):
    return max(lo, min(hi, v))


# --------------------------------------------------------------------- pieces
def make_sky() -> Sprite:
    sky = Sprite()
    sky.name = "sky"
    g = sky.graphics
    strips = 28
    sh = H / strips
    for i in range(strips):
        g.begin_fill(Color.lerp(SKY_TOP, SKY_BOTTOM, i / (strips - 1)))
        g.draw_rect(0, i * sh, W, sh + 1)
        g.end_fill()
    return sky


def make_sun() -> MovieClip:
    """MovieClip with two layers: a static disc and a rotating ray layer."""
    sun = MovieClip()
    sun.name = "sun"

    disc = Sprite()
    disc.graphics.line_style(2, (255, 176, 59))
    disc.graphics.begin_fill((255, 214, 79))
    disc.graphics.draw_circle(0, 0, 26)
    disc.graphics.end_fill()

    rays = Sprite()
    g = rays.graphics
    g.begin_fill((255, 202, 64))
    for i in range(8):
        a = i * math.pi / 4.0
        ca, sa = math.cos(a), math.sin(a)
        tip = (ca * 44, sa * 44)
        b1 = (ca * 30 - sa * 4, sa * 30 + ca * 4)
        b2 = (ca * 30 + sa * 4, sa * 30 - ca * 4)
        g.draw_poly([b1, tip, b2])
    g.end_fill()

    kf1 = sun.add_keyframe(1, layer=0)
    kf1.add_child(disc, name="disc")
    kf1r = sun.add_keyframe(1, layer=1)
    kf1r.add_child(rays, name="rays")
    # one full clockwise turn over 120 frames, looping forever
    sun.add_keyframe(121, layer=1, tween=TweenSpec(easing.Linear.ease_none,
                                                   rotate=1))
    return sun


def make_cloud() -> Sprite:
    cloud = Sprite()
    g = cloud.graphics
    g.begin_fill((255, 255, 255))
    g.draw_ellipse(-34, -8, 66, 30)
    g.draw_ellipse(-12, -20, 52, 36)
    g.draw_ellipse(8, -6, 58, 28)
    g.end_fill()
    return cloud


def make_hills() -> Sprite:
    hills = Sprite()
    g = hills.graphics
    g.begin_fill((126, 188, 96))
    g.draw_ellipse(-120, GROUND_Y - 28, 380, 120)
    g.draw_ellipse(230, GROUND_Y - 18, 420, 110)
    g.end_fill()
    g.begin_fill((104, 168, 82))
    g.draw_rect(-20, GROUND_Y + 26, W + 40, H - GROUND_Y)
    g.end_fill()
    return hills


def make_player() -> MovieClip:
    """A round red critter. Layer 1 holds eyelids used for a blink cycle."""
    player = MovieClip()
    player.name = "player"

    body = Sprite()
    g = body.graphics
    g.line_style(2.5, (140, 22, 22))
    g.begin_fill(Color.RED)
    g.draw_circle(0, 0, 27)
    g.end_fill()
    g.begin_fill((255, 128, 120))
    g.draw_ellipse(-16, 2, 32, 20)
    g.end_fill()
    # eyes
    g.line_style(0)
    g.begin_fill(Color.WHITE)
    g.draw_circle(-9, -10, 7)
    g.draw_circle(9, -10, 7)
    g.end_fill()
    g.begin_fill(INK)
    g.draw_circle(-7, -10, 3)
    g.draw_circle(11, -10, 3)
    g.end_fill()
    # beak
    g.begin_fill(Color.ORANGE)
    g.draw_poly([(-5, 0), (5, 0), (0, 8)])
    g.end_fill()
    # feet
    g.begin_fill((140, 22, 22))
    g.draw_ellipse(-16, 24, 14, 7)
    g.draw_ellipse(2, 24, 14, 7)
    g.end_fill()

    lids = Sprite()
    lg = lids.graphics
    lg.begin_fill((255, 120, 110))
    lg.draw_rect(-17, -19, 16, 10)
    lg.draw_rect(1, -19, 16, 10)
    lg.end_fill()

    body_layer = player.add_layer("body")
    player.add_layer("blink")
    kf1 = player.add_keyframe(1, layer=0)
    kf1.add_child(body, name="body")
    # eyelids visible frames 40..45, gone after -> blink every 120 frames
    player.add_keyframe(40, layer=1).add_child(lids, name="lids")
    player.add_keyframe(46, layer=1)  # empty keyframe hides the lids
    return player


def make_heart(size: float = 1.0) -> Sprite:
    heart = Sprite()
    g = heart.graphics
    g.line_style(1.5, (140, 22, 22))
    g.begin_fill(Color.RED)
    g.move_to(0, 6)
    g.curve_to(-8, 2, -8, -3)
    g.curve_to(-8, -8, -2, -8)
    g.curve_to(-1, -8, 0, -5)
    g.curve_to(1, -8, 2, -8)
    g.curve_to(8, -8, 8, -3)
    g.curve_to(8, 2, 0, 6)
    g.end_fill()
    heart.scale_x = heart.scale_y = size
    return heart


def make_star() -> Sprite:
    star = Sprite()
    g = star.graphics
    g.line_style(2, (214, 143, 18))
    g.begin_fill((255, 205, 64))
    g.draw_star(0, 0, 15, 6.5, 5)
    g.end_fill()
    g.line_style(0)
    g.begin_fill((255, 236, 160))
    g.draw_circle(-3, -4, 4.5)
    g.end_fill()
    return star


def make_button(label: str, w: float = 150) -> Sprite:
    btn = Sprite()
    btn.name = "btn_" + label.lower().replace(" ", "_")
    g = btn.graphics
    g.line_style(2, (140, 22, 22))
    g.begin_fill(Color.RED)
    g.draw_rounded_rect(-w / 2, -22, w, 44, 12)
    g.end_fill()
    txt = TextField(label, size=18, bold=True, color=Color.WHITE,
                    align="center", width=w)
    txt.x = -w / 2
    txt.y = -11
    btn.add_child(txt)
    return btn


def make_panel(w: float, h: float) -> Sprite:
    panel = Sprite()
    g = panel.graphics
    g.line_style(3, (140, 22, 22))
    g.begin_fill((253, 248, 236))
    g.draw_rounded_rect(-w / 2, -h / 2, w, h, 16)
    g.end_fill()
    return panel


# ----------------------------------------------------------------------- game
class Game:
    def __init__(self, stage: Stage):
        self.stage = stage
        self.score = 0
        self.lives = 3
        self.playing = False
        self.stars: list = []
        self.particles: list = []
        self.spawn_timer = 0
        self.target_x = W / 2

        self.root = Sprite()
        self.root.name = "game_root"
        stage.add_child(self.root)

        self.root.add_child(make_sky())

        self.sun = make_sun()
        self.sun.x, self.sun.y = W - 80, 74
        self.root.add_child(self.sun)

        self.clouds = []
        for i in range(3):
            c = make_cloud()
            c.x = random.uniform(-100, W)
            c.y = random.uniform(40, 150)
            c.scale_x = c.scale_y = random.uniform(0.6, 1.15)
            self.root.add_child(c)
            self.clouds.append(c)
            flashpy.tween(c, random.randint(320, 520), x=W + 150,
                          easing=easing.Linear.ease_none, repeat=-1,
                          delay=random.randint(0, 200))

        self.root.add_child(make_hills())

        # ------- HUD
        self.score_shadow = TextField("SCORE 0", size=20, bold=True,
                                      color=(90, 60, 40))
        self.score_text = TextField("SCORE 0", size=20, bold=True,
                                    color=Color.WHITE)
        self.score_shadow.x = self.score_text.x = 14
        self.score_shadow.y, self.score_text.y = 12, 11
        self.root.add_child(self.score_shadow)
        self.root.add_child(self.score_text)

        self.hearts = Sprite()
        self.hearts.x, self.hearts.y = W - 24, 24
        self.root.add_child(self.hearts)
        self._draw_hearts()

        # ------- player
        self.player = make_player()
        self.player.x, self.player.y = W / 2, GROUND_Y - 18
        self.root.add_child(self.player)
        # gentle idle bob
        flashpy.tween(self.player, 20, y=self.player.y - 4,
                      easing=easing.Sine.ease_in_out, yoyo=True, repeat=-1)

        # ------- menu panel
        self.menu = Sprite()
        self.menu.name = "menu"
        panel = make_panel(340, 210)
        self.menu.add_child(panel)
        title = TextField("STAR CATCHER", size=32, bold=True, color=INK,
                          align="center", width=340)
        title.x, title.y = -170, -78
        self.menu.add_child(title)
        sub = TextField("a flashpy demo", size=15, color=(150, 110, 80),
                        align="center", width=340)
        sub.x, sub.y = -170, -34
        self.menu.add_child(sub)

        self.play_btn = make_button("PLAY")
        self.play_btn.x, self.play_btn.y = 0, 20
        self.menu.add_child(self.play_btn)

        hint = TextField("mouse or arrow keys to move", size=12,
                         color=(150, 110, 80), align="center", width=340)
        hint.x, hint.y = -170, 62
        self.menu.add_child(hint)

        self.menu.x, self.menu.y = W / 2, -160
        self.root.add_child(self.menu)
        flashpy.tween(self.menu, 28, y=132, easing=easing.Back.ease_out)

        self.play_btn.add_event_listener("roll_over", self._on_btn_over)
        self.play_btn.add_event_listener("roll_out", self._on_btn_out)
        self.play_btn.add_event_listener("click", self._on_play)
        self.stage.add_event_listener("mouse_move", self._on_stage_move)

        self.sfx_click = sound.beep(540, ms=60, volume=0.25)
        self.sfx_catch = sound.beep(760, ms=80, volume=0.3)
        self.sfx_miss = sound.beep(150, ms=180, volume=0.3, kind="sine")

        self.stage.add_event_listener("enter_frame", self.on_enter_frame)

    # -------------------------------------------------------------- UI events
    def _on_btn_over(self, e):
        flashpy.tween(e.current_target, 7, scale_x=1.08, scale_y=1.08,
                      easing=easing.Back.ease_out)

    def _on_btn_out(self, e):
        flashpy.tween(e.current_target, 7, scale_x=1.0, scale_y=1.0,
                      easing=easing.Quad.ease_out)

    def _on_play(self, e):
        if self.sfx_click:
            self.sfx_click.play()
        self.start_game()

    def _on_stage_move(self, e):
        self.target_x = e.stage_x

    def start_game(self):
        self.playing = True
        self.play_btn.remove_event_listener("click", self._on_play)
        flashpy.tween(self.menu, 18, y=-220, easing=easing.Back.ease_in,
                      on_finish=lambda: setattr(self.menu, "visible", False))

    # -------------------------------------------------------------- gameplay
    def _draw_hearts(self):
        self.hearts.remove_all_children()
        for i in range(self.lives):
            h = make_heart(1.4)
            h.x = -i * 30
            self.hearts.add_child(h)

    def spawn_star(self, x=None):
        star = make_star()
        star.name = "star"
        star.x = random.uniform(40, W - 40) if x is None else x
        star.y = -30
        dur = max(55, random.randint(80, 110) - self.score // 5)
        self.root.add_child(star)
        self.stars.append(star)
        flashpy.tween(star, dur, y=H + 40, easing=easing.Quad.ease_in,
                      on_finish=lambda: self._star_landed(star))
        flashpy.tween(star, dur, rotation=random.choice([90, -90, 180]),
                      easing=easing.Linear.ease_none)

    def _star_landed(self, star):
        if star in self.stars:
            self.stars.remove(star)
            if star.parent:
                star.parent.remove_child(star)
            if self.playing:
                self.lives -= 1
                self._draw_hearts()
                if self.sfx_miss:
                    self.sfx_miss.play()
                self._shake()
                if self.lives <= 0:
                    self._game_over()

    def _shake(self):
        flashpy.tween(self.root, 2, x=7, yoyo=True, repeat=3,
                      easing=easing.Sine.ease_in_out,
                      on_finish=lambda: setattr(self.root, "x", 0))

    def _burst(self, x, y):
        colors = [(255, 205, 64), Color.RED, (255, 236, 160), Color.ORANGE]
        for i in range(9):
            p = Sprite()
            a = random.uniform(0, math.tau)
            dist = random.uniform(28, 64)
            tx, ty = math.cos(a) * dist, math.sin(a) * dist
            p.x, p.y = x, y
            g = p.graphics
            g.begin_fill(random.choice(colors))
            g.draw_circle(0, 0, random.uniform(4, 7))
            g.end_fill()
            self.root.add_child(p)
            self.particles.append(p)
            dur = random.randint(14, 22)
            flashpy.tween(p, dur, x=x + tx, y=y + ty,
                          easing=easing.Expo.ease_out)
            flashpy.tween(p, dur, alpha=0, scale_x=0.2, scale_y=0.2,
                          easing=easing.Quad.ease_out,
                          on_finish=lambda pp=p: self._remove_particle(pp))

    def _remove_particle(self, p):
        if p in self.particles:
            self.particles.remove(p)
        if p.parent:
            p.parent.remove_child(p)

    def _game_over(self):
        self.playing = False
        for s in list(self.stars):
            self.stage.remove_tweens_of(s)
            if s.parent:
                s.parent.remove_child(s)
        self.stars.clear()

        panel = Sprite()
        panel.name = "gameover"
        card = make_panel(340, 190)
        panel.add_child(card)
        t = TextField("GAME OVER", size=28, bold=True, color=INK,
                      align="center", width=340)
        t.x, t.y = -170, -66
        panel.add_child(t)
        s = TextField(f"final score: {self.score}", size=17,
                      color=(150, 110, 80), align="center", width=340)
        s.x, s.y = -170, -26
        panel.add_child(s)
        btn = make_button("PLAY AGAIN")
        btn.x, btn.y = 0, 32
        panel.add_child(btn)
        panel.x, panel.y = W / 2, -180
        self.root.add_child(panel)
        flashpy.tween(panel, 34, y=124, easing=easing.Bounce.ease_out)
        btn.add_event_listener("roll_over", self._on_btn_over)
        btn.add_event_listener("roll_out", self._on_btn_out)

        def restart(e):
            btn.remove_event_listener("click", restart)
            self.score = 0
            self.lives = 3
            self._update_score()
            self._draw_hearts()
            flashpy.tween(panel, 14, y=-220, easing=easing.Back.ease_in,
                          on_finish=lambda: panel.parent.remove_child(panel)
                          if panel.parent else None)
            self.playing = True

        btn.add_event_listener("click", restart)
        if self.sfx_click:
            self.sfx_click.play()

    def _update_score(self):
        self.score_text.text = f"SCORE {self.score}"
        self.score_shadow.text = f"SCORE {self.score}"

    # ------------------------------------------------------------------ tick
    def on_enter_frame(self, e):
        # ----- input: keyboard nudges the mouse target
        keys = self.stage.keys
        if pygame.K_LEFT in keys or pygame.K_a in keys:
            self.target_x -= 6.5
        if pygame.K_RIGHT in keys or pygame.K_d in keys:
            self.target_x += 6.5
        self.target_x = clamp(self.target_x, 40, W - 40)
        self.player.x += (self.target_x - self.player.x) * 0.22

        if not self.playing:
            return

        # ----- spawning (faster as the score grows)
        self.spawn_timer += 1
        interval = max(26, 52 - self.score // 4)
        if self.spawn_timer >= interval:
            self.spawn_timer = 0
            self.spawn_star()

        # ----- catching
        mouth_x, mouth_y = self.player.x, self.player.y - 16
        for star in list(self.stars):
            if math.hypot(star.x - mouth_x, star.y - mouth_y) < 40:
                self.stars.remove(star)
                self.stage.remove_tweens_of(star)
                if star.parent:
                    star.parent.remove_child(star)
                self.score += 10
                self._update_score()
                self._burst(star.x, star.y)
                if self.sfx_catch:
                    self.sfx_catch.play()
                flashpy.tween(self.player, 6, scale_x=1.12, scale_y=0.9,
                              yoyo=True, repeat=1,
                              easing=easing.Sine.ease_in_out)


def build(stage: Stage) -> Game:
    return Game(stage)


if __name__ == "__main__":
    stage = flashpy.init(W, H, caption="STAR CATCHER -- flashpy demo", fps=30)
    build(stage)
    flashpy.run(stage)
