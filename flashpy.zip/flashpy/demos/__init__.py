"""flashpy.demos -- example games built with the engine."""
from . import star_catcher  # noqa: F401

__all__ = ["star_catcher"]
