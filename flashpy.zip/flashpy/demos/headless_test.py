"""Headless verification for flashpy + the Star Catcher demo.

Runs the whole engine without a display (SDL dummy driver), asserts core
behaviors (easing, tweens, timelines, events, hit-testing, transforms) and
saves real screenshots of the demo into public/screenshots/.

    python flashpy/demos/headless_test.py
"""
from __future__ import annotations

import math
import os
import sys

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(
    os.path.abspath(__file__))))
sys.path.insert(0, _PROJECT_ROOT)

import pygame  # noqa: E402

import flashpy  # noqa: E402
from flashpy import Color, MovieClip, Sprite, Stage, TextField, easing  # noqa: E402
from flashpy.display import _Matrix  # noqa: E402
from flashpy.movieclip import TweenSpec  # noqa: E402

OUT_DIR = os.path.join(_PROJECT_ROOT, "public", "screenshots")

FAILURES = []


def check(name, cond, detail=""):
    status = "PASS" if cond else "FAIL"
    print(f"[{status}] {name}" + (f" -- {detail}" if detail and not cond else ""))
    if not cond:
        FAILURES.append(name)


class _FakeEv:
    def __init__(self, type, pos):
        self.type = type
        self.pos = pos
        self.button = 1


class _FakeKey:
    def __init__(self, key, uni=""):
        self.key = key
        self.unicode = uni
        self.mod = 0


def render_easing_chart():
    """Draw every easing family using the engine's own Graphics API."""
    families = list(easing.ALL_FAMILIES)
    cols, rows = 4, 3
    cell_w, cell_h = 210, 200
    margin = 20
    w = cols * cell_w + (cols + 1) * margin
    h = rows * cell_h + (rows + 1) * margin + 70
    root = Sprite()
    root.graphics.begin_fill((28, 22, 18))
    root.graphics.draw_rect(0, 0, w, h)
    root.graphics.end_fill()

    title = TextField("flashpy.easing -- the classic library", size=26,
                      bold=True, color=(255, 236, 200))
    title.x, title.y = margin, 16
    root.add_child(title)

    variants = [("ease_in", (255, 127, 39)), ("ease_out", (237, 28, 36)),
                ("ease_in_out", (255, 220, 130))]
    for idx, fam in enumerate(families):
        cx = margin + (idx % cols) * cell_w
        cy = 70 + margin + (idx // cols) * cell_h
        card = Sprite()
        card.x, card.y = cx, cy
        g = card.graphics
        g.begin_fill((44, 34, 27))
        g.draw_rounded_rect(0, 0, cell_w - 20, cell_h - 20, 10)
        g.end_fill()
        label = TextField(fam, size=16, bold=True, color=(255, 236, 200))
        label.x, label.y = 14, 8
        card.add_child(label)
        ox, oy, gw, gh = 24, 46, cell_w - 64, cell_h - 88
        g.line_style(1, (70, 56, 44))
        g.draw_line([(ox, oy), (ox, oy + gh), (ox + gw, oy + gh)])
        cls = getattr(easing, fam)
        for name, col in variants:
            fn = getattr(cls, name)
            pts = [(ox + t * gw, oy + (1.0 - fn(t)) * gh)
                   for t in [i / 60 for i in range(61)]]
            card.graphics.line_style(2, col)
            card.graphics.draw_line(pts)
        root.add_child(card)
    surf = pygame.Surface((w, h), pygame.SRCALPHA)
    root.render(surf, _Matrix())
    return surf


# ===========================================================================
# 1. Easing sanity
# ===========================================================================
check("easing linear", easing.Linear.ease_none(0.25) == 0.25)
check("quad ease_in(0.5)=0.25", abs(easing.Quad.ease_in(0.5) - 0.25) < 1e-9)
check("bounce ends at 1", abs(easing.Bounce.ease_out(1.0) - 1.0) < 1e-9)
check("back overshoots", easing.Back.ease_out(0.5) > 1.0)
check("elastic overshoots then settles", easing.Elastic.ease_out(0.2) > 1.0
      and min(easing.Elastic.ease_out(i / 100) for i in range(30, 90)) < 1.0)
for fam in easing.ALL_FAMILIES:
    cls = getattr(easing, fam)
    for fn in (cls.ease_in, cls.ease_out, cls.ease_in_out):
        assert abs(fn(0.0)) < 1e-9 and abs(fn(1.0) - 1.0) < 1e-9
check("all 11 families hit 0 and 1", True)

# ===========================================================================
# 2. Matrix math: rotation composition
# ===========================================================================
m = _Matrix().multiply(_Matrix(0, -1, 1, 0, 100, 100))  # 90 deg CW
x, y = m.apply(10, 0)
check("matrix 90deg rotation", abs(x - 100) < 1e-9 and abs(y - 110) < 1e-9,
      f"got ({x},{y})")

# ===========================================================================
# 3. Boot the stage headless and build the demo
# ===========================================================================
stage: Stage = flashpy.init(550, 400, caption="flashpy headless", fps=30,
                            headless=True)
check("stage created", stage is not None and stage.screen is not None)

from flashpy.demos.star_catcher import build  # noqa: E402

game = build(stage)
check("demo built", game is not None and game.menu is not None)


def step(n):
    for _ in range(n):
        stage.tick()
        stage.render()


def snap(name):
    os.makedirs(OUT_DIR, exist_ok=True)
    path = os.path.join(OUT_DIR, name)
    pygame.image.save(stage.screen, path)
    print(f"    saved {path}")


# ---- menu screenshot (after the panel's Back.ease_out drop-in)
step(30)
snap("flashpy-1.png")
check("menu panel settled", abs(game.menu.y - 132) < 1.5,
      f"menu.y={game.menu.y}")

# ===========================================================================
# 4. Programmatic tween engine
# ===========================================================================
probe = Sprite()
probe.x = 0.0
flashpy.tween(probe, 10, x=100, easing=easing.Quad.ease_out)
step(5)
mid = probe.x
check("tween mid progress (Quad out)", 55 < mid < 95, f"x={mid}")
step(6)
check("tween reaches target", abs(probe.x - 100) < 1e-6, f"x={probe.x}")

yo = Sprite()
yo.x = 0.0
flashpy.tween(yo, 4, x=40, yoyo=True, repeat=3)  # 4 half-cycles: ends home
step(4 * 4 + 1)
check("yoyo tween returns home", abs(yo.x - 0) < 1e-6, f"x={yo.x}")

# ===========================================================================
# 5. MovieClip timelines
# ===========================================================================
mc = MovieClip()
art = Sprite()
art.graphics.begin_fill(Color.RED)
art.graphics.draw_circle(0, 0, 10)
art.graphics.end_fill()
art.x = 0
kf1 = mc.add_keyframe(1)
kf1.add_child(art, name="art")
kf2 = mc.add_keyframe(20, tween=TweenSpec())
art.x = 200
kf2.add_child(art, name="art")
stage.add_child(mc)  # MovieClips tick while on the display list

mc.goto_and_play(1)
check("goto_and_play lands on frame 1, art at x=0",
      mc.current_frame == 1 and abs(art.x) < 1e-6,
      f"frame={mc.current_frame} x={art.x}")
step(19)
check("playhead advances + motion tween completes",
      mc.current_frame == 20 and abs(art.x - 200) < 1e-6,
      f"frame={mc.current_frame} x={art.x}")
step(1)
check("timeline loops back to frame 1",
      mc.current_frame == 1 and abs(art.x) < 1e-6,
      f"frame={mc.current_frame} x={art.x}")
mc.stop()
mc.goto_and_stop(10)
check("goto_and_stop interpolates mid-tween",
      abs(art.x - 200 * 9 / 19) < 1e-6, f"x={art.x}")

runs = []
mc.on_frame(5, lambda: runs.append(1))
mc.goto_and_play(1)
step(7)
check("frame script fired on frame 5", len(runs) == 1, f"runs={runs}")

# ===========================================================================
# 6. Events: click hit-testing + bubbling + roll over/out
# ===========================================================================
clicked = []
btn = Sprite()
btn.graphics.begin_fill(Color.RED)
btn.graphics.draw_rect(0, 0, 60, 30)
btn.graphics.end_fill()
btn.x, btn.y = 100, 100
btn.name = "btn"
stage.add_child(btn)
parent_hits = []
stage.add_event_listener("click", lambda e: parent_hits.append(e.target))
btn.add_event_listener("click", lambda e: clicked.append((e.stage_x, e.stage_y)))

stage.handle_event(_FakeEv(pygame.MOUSEBUTTONDOWN, (110, 110)))
stage.handle_event(_FakeEv(pygame.MOUSEBUTTONUP, (110, 110)))
check("click dispatched to button", len(clicked) == 1, f"clicked={clicked}")
check("click bubbled to stage with original target",
      len(parent_hits) == 1 and parent_hits[0] is btn,
      f"parent_hits={parent_hits}")

rolled = []
btn.add_event_listener("roll_over", lambda e: rolled.append("over"))
btn.add_event_listener("roll_out", lambda e: rolled.append("out"))
stage.handle_event(_FakeEv(pygame.MOUSEMOTION, (120, 115)))
stage.handle_event(_FakeEv(pygame.MOUSEMOTION, (10, 10)))
check("roll_over then roll_out", rolled == ["over", "out"], f"rolled={rolled}")
stage.remove_child(btn)

# ===========================================================================
# 7. Hit testing + world transforms (rotated parent)
# ===========================================================================
holder = Sprite()
holder.x, holder.y = 275, 200
holder.rotation = 90  # clockwise: local +x -> world +y
child = Sprite()
child.graphics.begin_fill(Color.GREEN)
child.graphics.draw_rect(0, 0, 40, 40)
child.graphics.end_fill()
child.x, child.y = 50, 0
holder.add_child(child)
stage.add_child(holder)
gx, gy = child.local_to_global(20, 20)
check("local_to_global through 90deg rotation",
      abs(gx - 255) < 1e-6 and abs(gy - 270) < 1e-6, f"got ({gx},{gy})")
hit = stage.hit_target(gx, gy)
check("hit test under rotated parent", hit is child, f"hit={hit}")
stage.remove_child(holder)

# ===========================================================================
# 8. TextField input
# ===========================================================================
field = TextField(input=True, width=200, size=16, border=Color.GRAY)
field.focused = True
stage.add_child(field)
field.handle_key(_FakeKey(pygame.K_h, "H"))
field.handle_key(_FakeKey(pygame.K_i, "i"))
check("text input works", field.text == "Hi", f"text={field.text!r}")
field.handle_key(_FakeKey(pygame.K_BACKSPACE))
check("backspace works", field.text == "H", f"text={field.text!r}")
stage.remove_child(field)

# ===========================================================================
# 9. Play the actual game: start, catch a star, screenshot the burst
# ===========================================================================
game.target_x = 275  # undo the synthetic mouse move from the event tests
game._on_play(None)  # the same handler the PLAY button fires
check("game started", game.playing, f"playing={game.playing}")

step(100)  # let stars fall for a while
check("stars spawned", len(game.stars) > 0, f"stars={len(game.stars)}")

# force a catch right at the player's mouth for a clean burst screenshot
game.spawn_star(x=game.player.x)
star = game.stars[-1]
star.x = game.player.x
star.y = game.player.y - 30
step(1)
game.on_enter_frame(None)
check("star caught, score increased", game.score > 0, f"score={game.score}")
step(1)
snap("flashpy-3.png")   # fresh particle burst at the player's mouth
step(8)
snap("flashpy-2.png")   # gameplay (burst faded, stars falling)

check("particles spawned", len(game.particles) > 0,
      f"particles={len(game.particles)}")
step(45)
check("particles cleaned up", len(game.particles) == 0,
      f"particles={len(game.particles)}")

# ===========================================================================
# 10. Nested transforms: scale + negative scale (mirror) + rotation render
# ===========================================================================
flip_test = Sprite()
flip_test.graphics.begin_fill(Color.PURPLE)
flip_test.graphics.draw_rect(-20, -20, 40, 40)
flip_test.graphics.end_fill()
flip_test.x, flip_test.y = 60, 60
flip_test.scale_x = -1
flip_test.rotation = 30
stage.add_child(flip_test)
step(3)
stage.remove_child(flip_test)
check("mirror scale + rotation renders", True)

# ===========================================================================
# 11. Easing reference chart (rendered with the engine itself)
# ===========================================================================
chart = render_easing_chart()
os.makedirs(OUT_DIR, exist_ok=True)
pygame.image.save(chart, os.path.join(OUT_DIR, "flashpy-4.png"))
print(f"    saved {os.path.join(OUT_DIR, 'flashpy-4.png')}")

# ===========================================================================
print()
if FAILURES:
    print(f"RESULT: {len(FAILURES)} FAILURE(S): {FAILURES}")
    sys.exit(1)
print("RESULT: ALL TESTS PASSED")
