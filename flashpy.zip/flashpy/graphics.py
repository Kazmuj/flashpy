"""flashpy.graphics -- a Flash-style vector drawing API.

Draw into any Sprite or MovieClip exactly like ActionScript::

    s = Sprite()
    g = s.graphics
    g.begin_fill(Color.RED)
    g.draw_circle(0, 0, 30)        # centered on the registration point
    g.end_fill()

Shapes are rasterized (2x supersampled for crispness) and cached until the
drawing changes.
"""
from __future__ import annotations

import math

import pygame


class _Prim:
    __slots__ = ("points", "fill", "line_width", "line_color", "closed")

    def __init__(self, points, fill, line_width, line_color, closed):
        self.points = points
        self.fill = fill
        self.line_width = line_width
        self.line_color = line_color
        self.closed = closed


def _circle_points(cx, cy, r, segments=0):
    if segments <= 0:
        segments = max(20, min(96, int(r * 1.2)))
    pts = []
    for i in range(segments):
        a = (2.0 * math.pi * i) / segments
        pts.append((cx + r * math.cos(a), cy + r * math.sin(a)))
    return pts


def _rounded_rect_points(x, y, w, h, r):
    r = max(0.0, min(r, w / 2.0, h / 2.0))
    pts = []
    corners = [
        (x + w - r, y + r, -math.pi / 2.0, 0.0),            # top-right
        (x + w - r, y + h - r, 0.0, math.pi / 2.0),         # bottom-right
        (x + r, y + h - r, math.pi / 2.0, math.pi),         # bottom-left
        (x + r, y + r, math.pi, 1.5 * math.pi),             # top-left
    ]
    for cx, cy, a0, a1 in corners:
        for i in range(9):
            a = a0 + (a1 - a0) * i / 8.0
            pts.append((cx + r * math.cos(a), cy + r * math.sin(a)))
    return pts


def _quad_bezier(p0, p1, p2, steps=24):
    pts = []
    for i in range(steps + 1):
        t = i / steps
        mt = 1.0 - t
        pts.append((mt * mt * p0[0] + 2 * mt * t * p1[0] + t * t * p2[0],
                    mt * mt * p0[1] + 2 * mt * t * p1[1] + t * t * p2[1]))
    return pts


class Graphics:
    """Records vector draw commands and rasterizes them to a cached surface."""

    SS = 2  # supersampling factor

    def __init__(self):
        self._prims: list = []
        self._fill = None           # (r,g,b) while a fill is active
        self._line_width = 0
        self._line_color = (0, 0, 0)
        self._path = None           # list of points for path API
        self._pos = (0.0, 0.0)
        self._version = 0
        self._cache = None          # (version, surface, origin_x, origin_y)
        self._tcache = {}           # transform cache for blitting

    # ------------------------------------------------------------------ state
    def clear(self) -> None:
        self._prims = []
        self._fill = None
        self._path = None
        self._pos = (0.0, 0.0)
        self._mark_dirty()

    def line_style(self, width: float = 0, color=(0, 0, 0)) -> None:
        """Set the stroke used by subsequent shapes (``width=0`` = none)."""
        self._line_width = max(0, int(round(width)))
        self._line_color = color

    def begin_fill(self, color) -> None:
        self._fill = color

    def end_fill(self) -> None:
        self._fill = None
        self._flush_path()

    def _mark_dirty(self):
        self._version += 1
        self._cache = None
        self._tcache = {}

    # ------------------------------------------------------------------ paths
    def move_to(self, x: float, y: float) -> None:
        self._pos = (x, y)
        self._path = [(x, y)]

    def line_to(self, x: float, y: float) -> None:
        if self._path is None:
            self._path = [self._pos]
        self._path.append((x, y))
        self._pos = (x, y)

    def curve_to(self, cx: float, cy: float, x: float, y: float) -> None:
        """Quadratic bezier from current position to ``(x, y)``."""
        if self._path is None:
            self._path = [self._pos]
        self._path.extend(_quad_bezier(self._pos, (cx, cy), (x, y))[1:])
        self._pos = (x, y)

    def stroke(self) -> None:
        """Stroke the current path with the current line style."""
        self._flush_path(closed=False)

    def close_path(self) -> None:
        if self._path:
            self._path.append(self._path[0])
        self._flush_path(closed=True)

    def _flush_path(self, closed: bool = None):
        if self._path and len(self._path) >= 2:
            if closed is None:
                closed = False
            self._prims.append(_Prim(list(self._path), self._fill,
                                     self._line_width, self._line_color, closed))
            self._mark_dirty()
        self._path = None

    # -------------------------------------------------------------- primitives
    def draw_rect(self, x: float, y: float, w: float, h: float) -> None:
        pts = [(x, y), (x + w, y), (x + w, y + h), (x, y + h)]
        self._prims.append(_Prim(pts, self._fill, self._line_width,
                                 self._line_color, True))
        self._mark_dirty()

    def draw_rounded_rect(self, x: float, y: float, w: float, h: float, r: float) -> None:
        pts = _rounded_rect_points(x, y, w, h, r)
        self._prims.append(_Prim(pts, self._fill, self._line_width,
                                 self._line_color, True))
        self._mark_dirty()

    def draw_circle(self, cx: float, cy: float, r: float) -> None:
        self._prims.append(_Prim(_circle_points(cx, cy, r), self._fill,
                                 self._line_width, self._line_color, True))
        self._mark_dirty()

    def draw_ellipse(self, x: float, y: float, w: float, h: float) -> None:
        """Ellipse inscribed in the bounding rect (Flash semantics)."""
        cx, cy = x + w / 2.0, y + h / 2.0
        rx, ry = w / 2.0, h / 2.0
        segs = 48
        pts = [(cx + rx * math.cos(2 * math.pi * i / segs),
                cy + ry * math.sin(2 * math.pi * i / segs)) for i in range(segs)]
        self._prims.append(_Prim(pts, self._fill, self._line_width,
                                 self._line_color, True))
        self._mark_dirty()

    def draw_poly(self, points, closed: bool = True) -> None:
        pts = [(float(p[0]), float(p[1])) for p in points]
        self._prims.append(_Prim(pts, self._fill, self._line_width,
                                 self._line_color, closed))
        self._mark_dirty()

    def draw_line(self, points) -> None:
        """Polyline stroked with the current line style."""
        pts = [(float(p[0]), float(p[1])) for p in points]
        self._prims.append(_Prim(pts, None, self._line_width,
                                 self._line_color, False))
        self._mark_dirty()

    def draw_star(self, cx: float, cy: float, r_out: float, r_in: float,
                  points: int = 5, rotation: float = -math.pi / 2.0) -> None:
        pts = []
        for i in range(points * 2):
            r = r_out if i % 2 == 0 else r_in
            a = rotation + math.pi * i / points
            pts.append((cx + r * math.cos(a), cy + r * math.sin(a)))
        self._prims.append(_Prim(pts, self._fill, self._line_width,
                                 self._line_color, True))
        self._mark_dirty()

    # ----------------------------------------------------------------- output
    def get_bounds(self):
        """Local bounding box ``(min_x, min_y, max_x, max_y)`` or ``None``."""
        if not self._prims:
            return None
        pad = 0.0
        xs, ys = [], []
        for p in self._prims:
            for (x, y) in p.points:
                xs.append(x)
                ys.append(y)
            if p.line_width:
                pad = max(pad, p.line_width / 2.0)
        if not xs:
            return None
        return (min(xs) - pad, min(ys) - pad, max(xs) + pad, max(ys) + pad)

    def render(self):
        """Rasterize into a cached surface.

        Returns ``(surface, origin_x, origin_y)`` where ``(origin_x, origin_y)``
        is the pixel inside the surface that corresponds to local ``(0, 0)``.
        """
        if self._cache and self._cache[0] == self._version:
            return self._cache[1:]

        bbox = self.get_bounds()
        if bbox is None:
            surf = pygame.Surface((1, 1), pygame.SRCALPHA)
            self._cache = (self._version, surf, 0, 0)
            return surf, 0, 0

        minx, miny, maxx, maxy = bbox
        w = max(1, int(math.ceil(maxx - minx)) + 1)
        h = max(1, int(math.ceil(maxy - miny)) + 1)
        origin_x = -minx
        origin_y = -miny

        ss = Graphics.SS
        surf = pygame.Surface((w * ss, h * ss), pygame.SRCALPHA)

        for p in self._prims:
            pts = [((x + origin_x) * ss, (y + origin_y) * ss)
                   for (x, y) in p.points]
            ipts = [(int(round(x)), int(round(y))) for (x, y) in pts]
            if p.fill is not None:
                if len(ipts) >= 3:
                    pygame.draw.polygon(surf, p.fill, ipts)
                    if len(p.fill) == 4 and p.fill[3] < 255:
                        pass  # alpha fills blend on the SRCALPHA surface
                else:
                    pygame.draw.lines(surf, p.fill, False, ipts, max(1, ss))
            if p.line_width and p.line_color is not None:
                lw = max(1, int(round(p.line_width * ss)))
                try:
                    pygame.draw.lines(surf, p.line_color, p.closed, ipts, lw)
                    if lw <= ss:
                        pygame.draw.aalines(surf, p.line_color, p.closed, ipts)
                except (ValueError, TypeError):
                    pass

        if ss > 1:
            surf = pygame.transform.smoothscale(surf, (w, h))

        self._cache = (self._version, surf, origin_x, origin_y)
        return surf, origin_x, origin_y


__all__ = ["Graphics"]
