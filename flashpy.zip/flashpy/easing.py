"""flashpy.easing -- the classic Robert Penner easing equations.

Organized exactly like Flash's ``fl.motion.easing`` classes: each class
exposes ``ease_in``, ``ease_out`` and ``ease_in_out`` static methods that
take a linear progress ``t`` in ``0..1`` and return the eased progress.

Example::

    from flashpy import easing

    flashpy.tween(ball, 30, x=400, easing=easing.Bounce.ease_out)
"""
from __future__ import annotations

import math


def _guard(t: float) -> float:
    if t <= 0.0:
        return 0.0
    if t >= 1.0:
        return 1.0
    return t


class Linear:
    """Constant speed. ``Linear.ease_none`` is the plain linear function."""

    @staticmethod
    def ease_none(t: float) -> float:
        return t

    ease_in = ease_out = ease_in_out = ease_none


class Sine:
    @staticmethod
    def ease_in(t: float) -> float:
        t = _guard(t)
        return 1.0 - math.cos(t * math.pi / 2.0)

    @staticmethod
    def ease_out(t: float) -> float:
        t = _guard(t)
        return math.sin(t * math.pi / 2.0)

    @staticmethod
    def ease_in_out(t: float) -> float:
        t = _guard(t)
        return -(math.cos(math.pi * t) - 1.0) / 2.0


class Quad:
    @staticmethod
    def ease_in(t: float) -> float:
        t = _guard(t)
        return t * t

    @staticmethod
    def ease_out(t: float) -> float:
        t = _guard(t)
        return 1.0 - (1.0 - t) * (1.0 - t)

    @staticmethod
    def ease_in_out(t: float) -> float:
        t = _guard(t)
        if t < 0.5:
            return 2.0 * t * t
        return 1.0 - ((-2.0 * t + 2.0) ** 2) / 2.0


class Cubic:
    @staticmethod
    def ease_in(t: float) -> float:
        t = _guard(t)
        return t * t * t

    @staticmethod
    def ease_out(t: float) -> float:
        t = _guard(t)
        return 1.0 - (1.0 - t) ** 3

    @staticmethod
    def ease_in_out(t: float) -> float:
        t = _guard(t)
        if t < 0.5:
            return 4.0 * t * t * t
        return 1.0 - ((-2.0 * t + 2.0) ** 3) / 2.0


class Quart:
    @staticmethod
    def ease_in(t: float) -> float:
        t = _guard(t)
        return t ** 4

    @staticmethod
    def ease_out(t: float) -> float:
        t = _guard(t)
        return 1.0 - (1.0 - t) ** 4

    @staticmethod
    def ease_in_out(t: float) -> float:
        t = _guard(t)
        if t < 0.5:
            return 8.0 * t ** 4
        return 1.0 - ((-2.0 * t + 2.0) ** 4) / 2.0


class Quint:
    @staticmethod
    def ease_in(t: float) -> float:
        t = _guard(t)
        return t ** 5

    @staticmethod
    def ease_out(t: float) -> float:
        t = _guard(t)
        return 1.0 - (1.0 - t) ** 5

    @staticmethod
    def ease_in_out(t: float) -> float:
        t = _guard(t)
        if t < 0.5:
            return 16.0 * t ** 5
        return 1.0 - ((-2.0 * t + 2.0) ** 5) / 2.0


class Expo:
    @staticmethod
    def ease_in(t: float) -> float:
        if t <= 0.0:
            return 0.0
        if t >= 1.0:
            return 1.0
        return 2.0 ** (10.0 * t - 10.0)

    @staticmethod
    def ease_out(t: float) -> float:
        if t <= 0.0:
            return 0.0
        if t >= 1.0:
            return 1.0
        return 1.0 - 2.0 ** (-10.0 * t)

    @staticmethod
    def ease_in_out(t: float) -> float:
        if t <= 0.0:
            return 0.0
        if t >= 1.0:
            return 1.0
        if t < 0.5:
            return 2.0 ** (20.0 * t - 10.0) / 2.0
        return (2.0 - 2.0 ** (-20.0 * t + 10.0)) / 2.0


class Circ:
    @staticmethod
    def ease_in(t: float) -> float:
        t = _guard(t)
        return 1.0 - math.sqrt(1.0 - t * t)

    @staticmethod
    def ease_out(t: float) -> float:
        t = _guard(t)
        return math.sqrt(1.0 - (t - 1.0) ** 2)

    @staticmethod
    def ease_in_out(t: float) -> float:
        t = _guard(t)
        if t < 0.5:
            return (1.0 - math.sqrt(1.0 - (2.0 * t) ** 2)) / 2.0
        return (math.sqrt(1.0 - (-2.0 * t + 2.0) ** 2) + 1.0) / 2.0


class Back:
    C1 = 1.70158
    C3 = C1 + 1.0
    C2 = C1 * 1.525

    @staticmethod
    def ease_in(t: float) -> float:
        t = _guard(t)
        c1, c3 = Back.C1, Back.C3
        return c3 * t * t * t - c1 * t * t

    @staticmethod
    def ease_out(t: float) -> float:
        t = _guard(t)
        c1, c3 = Back.C1, Back.C3
        return 1.0 + c3 * (t - 1.0) ** 3 + c1 * (t - 1.0) ** 2

    @staticmethod
    def ease_in_out(t: float) -> float:
        t = _guard(t)
        c2 = Back.C2
        if t < 0.5:
            return ((2.0 * t) ** 2 * ((c2 + 1.0) * 2.0 * t - c2)) / 2.0
        return ((2.0 * t - 2.0) ** 2 * ((c2 + 1.0) * (t * 2.0 - 2.0) + c2) + 2.0) / 2.0


class Elastic:
    C4 = (2.0 * math.pi) / 3.0
    C5 = (2.0 * math.pi) / 4.5

    @staticmethod
    def ease_in(t: float) -> float:
        if t <= 0.0:
            return 0.0
        if t >= 1.0:
            return 1.0
        return -(2.0 ** (10.0 * t - 10.0)) * math.sin((t * 10.0 - 10.75) * Elastic.C4)

    @staticmethod
    def ease_out(t: float) -> float:
        if t <= 0.0:
            return 0.0
        if t >= 1.0:
            return 1.0
        return (2.0 ** (-10.0 * t)) * math.sin((t * 10.0 - 0.75) * Elastic.C4) + 1.0

    @staticmethod
    def ease_in_out(t: float) -> float:
        if t <= 0.0:
            return 0.0
        if t >= 1.0:
            return 1.0
        if t < 0.5:
            return -(2.0 ** (20.0 * t - 10.0) * math.sin((20.0 * t - 11.125) * Elastic.C5)) / 2.0
        return (2.0 ** (-20.0 * t + 10.0) * math.sin((20.0 * t - 11.125) * Elastic.C5)) / 2.0 + 1.0


class Bounce:
    @staticmethod
    def ease_out(t: float) -> float:
        t = _guard(t)
        n1, d1 = 7.5625, 2.75
        if t < 1.0 / d1:
            return n1 * t * t
        if t < 2.0 / d1:
            return n1 * (t - 1.5 / d1) ** 2 + 0.75
        if t < 2.5 / d1:
            return n1 * (t - 2.25 / d1) ** 2 + 0.9375
        return n1 * (t - 2.625 / d1) ** 2 + 0.984375

    @staticmethod
    def ease_in(t: float) -> float:
        return 1.0 - Bounce.ease_out(1.0 - _guard(t))

    @staticmethod
    def ease_in_out(t: float) -> float:
        t = _guard(t)
        if t < 0.5:
            return (1.0 - Bounce.ease_out(1.0 - 2.0 * t)) / 2.0
        return (1.0 + Bounce.ease_out(2.0 * t - 1.0)) / 2.0


ALL_FAMILIES = ["Linear", "Sine", "Quad", "Cubic", "Quart", "Quint",
                "Expo", "Circ", "Back", "Elastic", "Bounce"]

__all__ = ["Linear", "Sine", "Quad", "Cubic", "Quart", "Quint", "Expo",
           "Circ", "Back", "Elastic", "Bounce", "ALL_FAMILIES"]
