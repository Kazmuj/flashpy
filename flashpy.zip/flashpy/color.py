"""flashpy.color -- color helpers and a Flash-flavored palette.

Colors are plain ``(r, g, b)`` or ``(r, g, b, a)`` tuples so they plug
directly into pygame.
"""
from __future__ import annotations


def hex_to_rgb(value: str) -> tuple:
    """Convert ``"#ffcc00"`` (or ``"#fc0"``) to an ``(r, g, b)`` tuple."""
    v = value.lstrip("#")
    if len(v) == 3:
        v = "".join(c * 2 for c in v)
    if len(v) != 6:
        raise ValueError(f"Invalid hex color: {value!r}")
    return tuple(int(v[i:i + 2], 16) for i in (0, 2, 4))


def with_alpha(color: tuple, alpha: float) -> tuple:
    """Return ``color`` expanded to RGBA with ``alpha`` in ``0..1``."""
    r, g, b = color[0], color[1], color[2]
    return (r, g, b, max(0, min(255, int(alpha * 255))))


def lerp_color(c1: tuple, c2: tuple, t: float) -> tuple:
    """Linearly interpolate two RGB(A) colors. ``t`` is clamped to 0..1."""
    t = max(0.0, min(1.0, t))
    n = min(len(c1), len(c2))
    out = []
    for i in range(n):
        out.append(int(round(c1[i] + (c2[i] - c1[i]) * t)))
    return tuple(out)


class Color:
    """Named colors from the classic Flash SWF palette, plus helpers."""

    BLACK = (0, 0, 0)
    WHITE = (255, 255, 255)
    RED = (237, 28, 36)
    ORANGE = (255, 127, 39)
    YELLOW = (255, 241, 0)
    GREEN = (52, 166, 74)
    BLUE = (0, 102, 204)
    PURPLE = (146, 39, 143)
    PINK = (255, 153, 204)
    BROWN = (89, 52, 30)
    GRAY = (153, 153, 153)
    LIGHT_GRAY = (221, 221, 221)
    DARK_GRAY = (64, 64, 64)
    SKY = (142, 202, 230)
    CREAM = (253, 246, 227)
    TRANSPARENT = (0, 0, 0, 0)

    hex = staticmethod(hex_to_rgb)
    with_alpha = staticmethod(with_alpha)
    lerp = staticmethod(lerp_color)


__all__ = ["Color", "hex_to_rgb", "with_alpha", "lerp_color"]
