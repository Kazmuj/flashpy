"""flashpy.run -- bootstrapping and the main loop.

    import flashpy
    from flashpy import Sprite, Color

    stage = flashpy.init(550, 400, caption="Hello")
    ball = Sprite()
    ball.graphics.begin_fill(Color.RED)
    ball.graphics.draw_circle(0, 0, 40)
    ball.graphics.end_fill()
    ball.x, ball.y = 275, 200
    stage.add_child(ball)
    flashpy.run(stage)
"""
from __future__ import annotations

import os

import pygame

from .display import Stage

_stage: Stage = None


def init(width: int = 550, height: int = 400, caption: str = "flashpy",
         fps: int = 30, bg_color=(255, 255, 255), headless: bool = False) -> Stage:
    """Create the window (or a dummy screen when ``headless=True``) and Stage."""
    global _stage
    if headless:
        os.environ["SDL_VIDEODRIVER"] = "dummy"
        os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
    if not pygame.get_init():
        pygame.init()
    if not pygame.font.get_init():
        pygame.font.init()
    screen = pygame.display.set_mode((int(width), int(height)))
    pygame.display.set_caption(caption)
    try:
        pygame.mixer.init()
    except pygame.error:
        pass
    _stage = Stage(int(width), int(height), screen, bg_color, int(fps), caption)
    return _stage


def current_stage() -> Stage:
    return _stage


def tween(target, duration: int, **kwargs):
    """Stage-level tween sugar. See :class:`flashpy.tween.Tween`."""
    if _stage is None:
        raise RuntimeError("call flashpy.init() before flashpy.tween()")
    return _stage.add_tween(target, duration, **kwargs)


def run(stage: Stage = None) -> None:
    """Run the main loop until the window closes or ``stage.quit()``."""
    stage = stage or _stage
    if stage is None:
        raise RuntimeError("call flashpy.init() first")
    clock = pygame.time.Clock()
    while not stage.quit_requested:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                stage.quit()
            else:
                stage.handle_event(event)
        stage.tick()
        stage.render()
        pygame.display.flip()
        clock.tick(stage.fps)
    pygame.quit()


__all__ = ["init", "current_stage", "tween", "run"]
