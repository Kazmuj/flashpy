"""flashpy.events -- Flash-style event dispatching.

Any display object can listen for events, exactly like ActionScript 3::

    def on_click(e):
        print("clicked at", e.stage_x, e.stage_y)

    button.add_event_listener("click", on_click)
    button.remove_event_listener("click", on_click)
"""
from __future__ import annotations


class Event:
    """A basic event. Extra keyword args become attributes."""

    def __init__(self, event_type: str, bubbles: bool = False, **data):
        self.type = event_type
        self.bubbles = bubbles
        self.target = None
        self.current_target = None
        for k, v in data.items():
            setattr(self, k, v)

    def __repr__(self):
        return f"<Event '{self.type}' target={self.target!r}>"


class EventType:
    """Built-in (non-mouse) event type constants."""

    ENTER_FRAME = "enter_frame"
    ADDED = "added"
    REMOVED = "removed"
    COMPLETE = "complete"
    TWEEN_START = "tween_start"
    TWEEN_UPDATE = "tween_update"
    TWEEN_FINISH = "tween_finish"


class MouseEventTypes:
    MOUSE_DOWN = "mouse_down"
    MOUSE_UP = "mouse_up"
    MOUSE_MOVE = "mouse_move"
    CLICK = "click"
    ROLL_OVER = "roll_over"
    ROLL_OUT = "roll_out"


class MouseEvent(Event):
    """Mouse event with stage and local coordinates."""

    def __init__(self, event_type: str, stage_x: float = 0.0, stage_y: float = 0.0,
                 button: int = 0, bubbles: bool = True, **data):
        super().__init__(event_type, bubbles=bubbles, **data)
        self.stage_x = stage_x
        self.stage_y = stage_y
        self.button = button
        self.local_x = stage_x
        self.local_y = stage_y


class KeyboardEvent(Event):
    """Keyboard event. ``key`` is a ``pygame.K_*`` constant."""

    def __init__(self, event_type: str, key=None, key_name: str = "",
                 unicode: str = "", mods: int = 0, **data):
        super().__init__(event_type, **data)
        self.key = key
        self.key_name = key_name
        self.unicode = unicode
        self.mods = mods


class EventDispatcher:
    """Minimal, fast observer pattern -- the base of every display object."""

    def __init__(self):
        self._listeners: dict = {}

    def add_event_listener(self, event_type: str, listener) -> None:
        """Register ``listener(event)`` for ``event_type`` (a string)."""
        lst = self._listeners.setdefault(event_type, [])
        if listener not in lst:
            lst.append(listener)

    def remove_event_listener(self, event_type: str, listener) -> None:
        lst = self._listeners.get(event_type)
        if lst and listener in lst:
            lst.remove(listener)
            if not lst:
                self._listeners.pop(event_type, None)

    def has_event_listener(self, event_type: str) -> bool:
        return bool(self._listeners.get(event_type))

    def remove_all_listeners(self, event_type: str = None) -> None:
        if event_type is None:
            self._listeners.clear()
        else:
            self._listeners.pop(event_type, None)

    def _emit(self, event: Event) -> None:
        """Call local listeners only (no bubbling)."""
        event.current_target = self
        for listener in list(self._listeners.get(event.type, ())):
            listener(event)

    def dispatch_event(self, event: Event) -> None:
        """Dispatch on this object only (no bubbling)."""
        if event.target is None:
            event.target = self
        self._emit(event)

    def dispatch(self, event_type: str, bubbles: bool = False, **data) -> Event:
        """Create and dispatch an event in one call."""
        event = Event(event_type, bubbles=bubbles, **data)
        self.dispatch_event(event)
        return event


__all__ = ["Event", "EventType", "MouseEventTypes", "MouseEvent",
           "KeyboardEvent", "EventDispatcher"]
