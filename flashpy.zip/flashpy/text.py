"""flashpy.text -- dynamic and input TextFields.

    score = TextField("SCORE 0", size=20, bold=True, color=Color.WHITE)
    name_field = TextField(input=True, width=200, border=Color.GRAY)
"""
from __future__ import annotations

import pygame

from .display import DisplayObject, _blit_transformed

_font_cache: dict = {}


def _font(size: int, bold: bool, italic: bool, name=None):
    key = (name, size, bold, italic)
    if key not in _font_cache:
        if name:
            f = pygame.font.SysFont(name, size, bold=bold, italic=italic)
        else:
            f = pygame.font.Font(None, size)
            f.set_bold(bold)
            f.set_italic(italic)
        _font_cache[key] = f
    return _font_cache[key]


class TextField(DisplayObject):
    """Renders text. With ``input=True`` it becomes an editable field."""

    def __init__(self, text: str = "", width: float = None, size: int = 14,
                 color=(0, 0, 0), font=None, bold: bool = False,
                 italic: bool = False, align: str = "left",
                 multiline: bool = False, input: bool = False,
                 background=None, border=None, line_spacing: int = 3,
                 max_chars: int = 0):
        super().__init__()
        self._text = str(text)
        self._width = width
        self._size = int(size)
        self._color = color
        self._font_name = font
        self._bold = bold
        self._italic = italic
        self._align = align
        self._multiline = multiline
        self.input = input
        self._background = background
        self._border = border
        self._line_spacing = line_spacing
        self.max_chars = max_chars
        self._caret = len(self._text)
        self.focused = False
        self._version = 0
        self._cache = None
        self._tcache: dict = {}

    def _mark_dirty(self):
        self._version += 1
        self._cache = None
        self._tcache = {}

    # ----------------------------------------------------------- properties
    @property
    def text(self) -> str:
        return self._text

    @text.setter
    def text(self, value: str):
        self._text = str(value)
        self._caret = min(self._caret, len(self._text))
        self._mark_dirty()

    @property
    def width(self) -> float:
        if self._width:
            return self._width
        lines, w, _h = self._layout()
        return w

    @width.setter
    def width(self, value: float):
        self._width = value
        self._mark_dirty()

    @property
    def size(self) -> int:
        return self._size

    @size.setter
    def size(self, value: int):
        self._size = int(value)
        self._mark_dirty()

    @property
    def color(self):
        return self._color

    @color.setter
    def color(self, value):
        self._color = value
        self._mark_dirty()

    # --------------------------------------------------------------- layout
    def _layout(self):
        """Return ``(lines, width, height)`` of the laid-out text."""
        font = _font(self._size, self._bold, self._italic, self._font_name)
        line_h = font.get_linesize() + self._line_spacing
        raw = self._text.split("\n")
        if self._width:
            wrapped = []
            for para in raw:
                words = para.split(" ")
                cur = ""
                for word in words:
                    test = (cur + " " + word).strip()
                    if font.size(test)[0] <= self._width - 4 or not cur:
                        cur = test
                    else:
                        wrapped.append(cur)
                        cur = word
                wrapped.append(cur)
            lines = wrapped
        else:
            lines = raw
        w = max((font.size(ln)[0] for ln in lines), default=0) + 4
        if self._width:
            w = self._width
        h = line_h * len(lines) + 4
        return lines, w, h, font

    def get_bounds(self):
        _lines, w, h, _font = self._layout()
        return (0, 0, max(1, w), max(1, h))

    # -------------------------------------------------------------- editing
    def append_text(self, s: str) -> None:
        if self.max_chars and len(self._text) + len(s) > self.max_chars:
            s = s[: max(0, self.max_chars - len(self._text))]
        self._text = self._text[:self._caret] + s + self._text[self._caret:]
        self._caret += len(s)
        self._mark_dirty()

    def handle_key(self, event) -> None:
        if not self.input:
            return
        key = event.key
        if key == pygame.K_BACKSPACE:
            if self._caret > 0:
                self._text = self._text[:self._caret - 1] + self._text[self._caret:]
                self._caret -= 1
        elif key == pygame.K_DELETE:
            self._text = self._text[:self._caret] + self._text[self._caret + 1:]
        elif key == pygame.K_LEFT:
            self._caret = max(0, self._caret - 1)
        elif key == pygame.K_RIGHT:
            self._caret = min(len(self._text), self._caret + 1)
        elif key in (pygame.K_RETURN, pygame.K_KP_ENTER):
            if self._multiline:
                self.append_text("\n")
        elif event.unicode and ord(event.unicode) >= 32:
            self.append_text(event.unicode)
        else:
            return
        self._mark_dirty()

    # ------------------------------------------------------------- rendering
    def _render_self(self, surface, world) -> None:
        if self._cache is None or self._cache[0] != self._version:
            lines, w, h, font = self._layout()
            w = max(1, int(w))
            h = max(1, int(h))
            img = pygame.Surface((w, h), pygame.SRCALPHA)
            if self._background is not None:
                img.fill(self._background)
            line_h = font.get_linesize() + self._line_spacing
            for i, ln in enumerate(lines):
                if not ln:
                    continue
                rendered = font.render(ln, True, self._color)
                lw = rendered.get_width()
                if self._align == "center":
                    x = (w - lw) // 2
                elif self._align == "right":
                    x = w - lw - 2
                else:
                    x = 2
                img.blit(rendered, (x, 2 + i * line_h))
            if self._border is not None:
                pygame.draw.rect(img, self._border, (0, 0, w, h), 1)
            if self.input and self.focused:
                # caret: position of text before the caret on its line
                ci, cx = self._caret_line_pos(lines, font)
                cy = 2 + ci * line_h
                pygame.draw.line(img, self._color,
                                 (cx, cy), (cx, cy + font.get_linesize()), 1)
            self._cache = (self._version, img, 0, 0)

        _ver, img, ox, oy = self._cache
        _blit_transformed(surface, img, (ox, oy), world,
                          self.effective_alpha(), self._tcache)

    def _caret_line_pos(self, lines, font):
        count = 0
        for i, ln in enumerate(lines):
            if self._caret <= count + len(ln):
                off = self._caret - count
                x = 2 + font.size(ln[:off])[0]
                return i, min(x, (self._width or 100000) - 2)
            count += len(ln) + 1  # +1 for the newline
        return len(lines) - 1, 2 + font.size(lines[-1])[0] if lines else (0, 2)


__all__ = ["TextField"]
