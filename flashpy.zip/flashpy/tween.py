"""flashpy.tween -- one-liner property tweens, Flash style.

Duration is measured in *frames* (like the Flash timeline), not seconds::

    flashpy.tween(ball, 30, x=400, easing=easing.Bounce.ease_out)
    flashpy.tween(star, 90, rotation=360, repeat=-1)          # forever
    flashpy.tween(panel, 24, y=300, yoyo=True, repeat=5)
"""
from __future__ import annotations

from .easing import Linear
from .events import Event, EventType


class Tween:
    """Animate numeric properties of any object over N frames."""

    def __init__(self, manager: "TweenManager", target, duration: int,
                 easing=Linear.ease_none, delay: int = 0, yoyo: bool = False,
                 repeat: int = 0, on_start=None, on_update=None, on_finish=None,
                 **props):
        self.manager = manager
        self.target = target
        self.duration = max(1, int(duration))
        self.easing = easing
        self.delay = max(0, int(delay))
        self.yoyo = bool(yoyo)
        self.repeat = int(repeat)          # extra plays; -1 = forever
        self.on_start = on_start
        self.on_update = on_update
        self.on_finish = on_finish
        for k, v in props.items():
            if isinstance(v, bool) or not isinstance(v, (int, float)):
                raise TypeError(
                    f"Tween property '{k}' must be numeric, got {type(v).__name__}")
        self.props = props
        self._start_vals: dict = {}
        self._end_vals: dict = dict(props)
        self._elapsed = 0
        self._delay_left = self.delay
        self._started = False
        self._done = False
        self._removed = False

    # ----------------------------------------------------------------- state
    @property
    def done(self):
        return self._done

    def remove(self):
        self._removed = True

    def _capture(self):
        for k in self.props:
            cur = getattr(self.target, k, 0.0)
            if isinstance(cur, bool) or not isinstance(cur, (int, float)):
                cur = 0.0
            self._start_vals[k] = float(cur)

    def _apply(self, eased: float):
        for k, end in self._end_vals.items():
            start = self._start_vals[k]
            try:
                setattr(self.target, k, start + (end - start) * eased)
            except AttributeError:
                pass

    # ------------------------------------------------------------------ tick
    def update(self) -> None:
        if self._done or self._removed:
            return
        if self._delay_left > 0:
            self._delay_left -= 1
            return
        if not self._started:
            self._capture()
            self._started = True
            if self.on_start:
                self.on_start()

        self._elapsed += 1
        t = min(1.0, self._elapsed / self.duration)
        eased = self.easing(t)
        self._apply(eased)
        if self.on_update:
            self.on_update()

        if t >= 1.0:
            if self.repeat != 0:
                if self.repeat > 0:
                    self.repeat -= 1
                if self.yoyo:
                    self._start_vals, self._end_vals = \
                        self._end_vals, self._start_vals
                self._elapsed = 0
            else:
                self._done = True
                if self.on_finish:
                    self.on_finish()


class TweenManager:
    """Owns and advances all tweens (one lives on the Stage)."""

    def __init__(self):
        self._tweens: list = []

    def add(self, target, duration: int, **kwargs) -> Tween:
        tw = Tween(self, target, duration, **kwargs)
        self._tweens.append(tw)
        return tw

    def add_tween_object(self, tw: Tween) -> Tween:
        tw.manager = self
        self._tweens.append(tw)
        return tw

    def remove(self, tween: Tween) -> None:
        tween.remove()

    def remove_tweens_of(self, target) -> None:
        for tw in self._tweens:
            if tw.target is target:
                tw.remove()

    def clear(self) -> None:
        for tw in self._tweens:
            tw.remove()

    def update_all(self) -> None:
        alive = []
        for tw in self._tweens:
            tw.update()
            if not tw._done and not tw._removed:
                alive.append(tw)
        self._tweens = alive


__all__ = ["Tween", "TweenManager"]
