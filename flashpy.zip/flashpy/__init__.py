"""flashpy -- an Adobe Flash-style game engine built on pygame.

MovieClips, frame timelines, keyframe motion tweens, the classic Penner
easing library, a vector Graphics API, bubbling mouse events, TextFields
and a fixed-size Stage -- everything you remember from the Flash IDE.

Quick start::

    import flashpy
    from flashpy import Sprite, Color

    stage = flashpy.init(550, 400, caption="Hello Flash")

    ball = Sprite()
    ball.graphics.begin_fill(Color.RED)
    ball.graphics.draw_circle(0, 0, 40)
    ball.graphics.end_fill()
    ball.x, ball.y = 275, 200
    stage.add_child(ball)

    flashpy.run(stage)
"""
from .color import Color
from .display import (DisplayObject, DisplayObjectContainer, Sprite, Stage,
                      _Matrix)
from .easing import (Back, Bounce, Circ, Cubic, Elastic, Expo, Linear, Quad,
                     Quart, Quint, Sine)
from .events import (Event, EventDispatcher, EventType, KeyboardEvent,
                     MouseEvent)
from .graphics import Graphics
from .movieclip import Keyframe, MovieClip, Timeline, TweenSpec
from .run import current_stage, init, run, tween
from .sound import Sound, beep
from .text import TextField
from .tween import Tween, TweenManager

__version__ = "1.0.0"

__all__ = [
    "Color", "DisplayObject", "DisplayObjectContainer", "Sprite", "Stage",
    "Graphics", "MovieClip", "Timeline", "Keyframe", "TweenSpec",
    "TextField", "Tween", "TweenManager", "Sound", "beep",
    "Event", "EventDispatcher", "EventType", "MouseEvent", "KeyboardEvent",
    "Linear", "Sine", "Quad", "Cubic", "Quart", "Quint", "Expo", "Circ",
    "Back", "Elastic", "Bounce",
    "init", "run", "tween", "current_stage", "_Matrix",
]
