"""flashpy.sound -- tiny sound helpers (no external assets required).

    from flashpy import sound

    sound.beep(880, ms=90).play()          # synth a note and play it
    sfx = sound.Sound("explosion.wav")
    sfx.play(volume=0.5)
"""
from __future__ import annotations

import math
import struct

import pygame


def available() -> bool:
    return pygame.mixer.get_init() is not None


class Sound:
    """Thin wrapper over ``pygame.mixer.Sound``."""

    def __init__(self, file: str = None, buffer: bytes = None):
        if file is not None:
            self._snd = pygame.mixer.Sound(file)
        elif buffer is not None:
            self._snd = pygame.mixer.Sound(buffer=buffer)
        else:
            raise ValueError("Sound needs a file or a buffer")

    def play(self, loops: int = 0, volume: float = 1.0):
        if not available():
            return None
        ch = self._snd.play(loops=loops)
        if ch is not None:
            ch.set_volume(max(0.0, min(1.0, volume)))
        return ch

    def stop(self):
        self._snd.stop()


def beep(freq: float = 880.0, ms: int = 90, volume: float = 0.3,
         kind: str = "square"):
    """Synthesize a short note (square/sine/saw) and return a Sound."""
    if not available():
        return None
    rate = 22050
    n = int(rate * ms / 1000)
    buf = bytearray()
    for i in range(n):
        t = i / rate
        phase = 2.0 * math.pi * freq * t
        if kind == "sine":
            v = math.sin(phase)
        elif kind == "saw":
            v = ((freq * t) % 1.0) * 2.0 - 1.0
        else:
            v = 1.0 if math.sin(phase) >= 0 else -1.0
        envelope = 1.0 - (i / n)
        sample = int(max(-1.0, min(1.0, v * envelope)) * volume * 32767)
        buf += struct.pack("<h", sample)
    try:
        return Sound(buffer=bytes(buf))
    except pygame.error:
        return None


__all__ = ["Sound", "beep", "available"]
