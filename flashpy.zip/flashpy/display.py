"""flashpy.display -- the display list: Stage, Sprite and transform rendering.

Implements the Flash scene graph: nested containers, ``x / y / rotation /
scale_x / scale_y / alpha / pivot`` transforms, depth-ordered rendering and
point hit-testing -- all on top of pygame surfaces.
"""
from __future__ import annotations

import math

import pygame

from .events import Event, EventDispatcher, EventType, KeyboardEvent, MouseEvent
from .graphics import Graphics
from .tween import Tween, TweenManager

_ADJ = 2  # hit-test padding in px


class _Matrix:
    """2x3 affine transform: ``[[a, b, tx], [c, d, ty]]``."""

    __slots__ = ("a", "b", "c", "d", "tx", "ty")

    def __init__(self, a=1.0, b=0.0, c=0.0, d=1.0, tx=0.0, ty=0.0):
        self.a, self.b, self.c, self.d = a, b, c, d
        self.tx, self.ty = tx, ty

    def multiply(self, m: "_Matrix") -> "_Matrix":
        """Return ``self ∘ m`` (apply ``m`` first, then ``self``)."""
        return _Matrix(
            self.a * m.a + self.b * m.c,
            self.a * m.b + self.b * m.d,
            self.c * m.a + self.d * m.c,
            self.c * m.b + self.d * m.d,
            self.a * m.tx + self.b * m.ty + self.tx,
            self.c * m.tx + self.d * m.ty + self.ty,
        )

    def apply(self, x: float, y: float):
        return (self.a * x + self.b * y + self.tx,
                self.c * x + self.d * y + self.ty)

    def apply_inverse(self, x: float, y: float):
        det = self.a * self.d - self.b * self.c
        if abs(det) < 1e-9:
            return (0.0, 0.0)
        dx, dy = x - self.tx, y - self.ty
        return ((self.d * dx - self.b * dy) / det,
                (self.a * dy - self.c * dx) / det)

    def decompose(self):
        """Return ``(theta_degrees, scale_x, scale_y, flip_x)``.

        Rotation follows the Flash convention: positive = clockwise on screen.
        """
        det = self.a * self.d - self.b * self.c
        flip = det < 0
        a2, c2 = (-self.a, -self.c) if flip else (self.a, self.c)
        sx = math.hypot(a2, c2)
        theta = math.atan2(c2, a2)
        sy = math.hypot(self.b, self.d)
        return math.degrees(theta), sx, sy, flip

    def __repr__(self):
        return f"Matrix(a={self.a:.2f}, b={self.b:.2f}, c={self.c:.2f}, d={self.d:.2f}, tx={self.tx:.1f}, ty={self.ty:.1f})"


def _blit_transformed(target: pygame.Surface, src: pygame.Surface,
                      origin: tuple, matrix: _Matrix, alpha: float,
                      cache: dict = None) -> None:
    """Blit ``src`` onto ``target`` transformed by ``matrix``.

    ``origin`` is the pixel inside ``src`` that represents local ``(0, 0)``.
    """
    origin_x, origin_y = origin
    theta_deg, sx, sy, flip = matrix.decompose()

    identity = (abs(theta_deg) < 1e-4 and abs(sx - 1.0) < 1e-3
                and abs(sy - 1.0) < 1e-3 and not flip)
    if identity:
        pos = (round(matrix.tx - origin_x), round(matrix.ty - origin_y))
        _blit_with_alpha(target, src, pos, alpha)
        return

    key = (round(theta_deg, 1), round(sx, 2), round(sy, 2), flip)
    out = None
    if cache is not None:
        cached = cache.get(key)
        if cached is not None and cached[0] is src:
            out = cached[1]

    if out is None:
        w, h = src.get_size()
        sx = max(0.01, sx)
        sy = max(0.01, sy)
        nw, nh = max(1, round(w * sx)), max(1, round(h * sy))
        surf = src
        ox, oy = origin_x, origin_y
        if abs(sx - 1.0) > 1e-3 or abs(sy - 1.0) > 1e-3:
            surf = pygame.transform.smoothscale(surf, (nw, nh))
            fx, fy = surf.get_width() / w, surf.get_height() / h
            ox, oy = ox * fx, oy * fy
        if flip:
            surf = pygame.transform.flip(surf, True, False)
            ox = surf.get_width() - ox
        theta = math.radians(theta_deg)
        if abs(theta_deg) > 1e-4:
            cw, ch = surf.get_size()
            surf = pygame.transform.rotate(surf, -theta_deg)  # CW positive
            dw, dh = surf.get_size()
            cx, cy = cw / 2.0, ch / 2.0
            dx, dy = ox - cx, oy - cy
            cos_t, sin_t = math.cos(theta), math.sin(theta)
            ox = dw / 2.0 + dx * cos_t - dy * sin_t
            oy = dh / 2.0 + dx * sin_t + dy * cos_t
        out = (surf, ox, oy)
        if cache is not None:
            cache[key] = (src, out)

    surf, ox, oy = out
    pos = (round(matrix.tx - ox), round(matrix.ty - oy))
    _blit_with_alpha(target, surf, pos, alpha)


def _blit_with_alpha(target: pygame.Surface, src: pygame.Surface,
                     pos: tuple, alpha: float) -> None:
    if alpha >= 0.999:
        target.blit(src, pos)
        return
    tmp = src.copy()
    tmp.set_alpha(max(0, int(alpha * 255)))
    target.blit(tmp, pos)


class DisplayObject(EventDispatcher):
    """Base object of the display list (position, transform, visibility)."""

    def __init__(self):
        super().__init__()
        self.name = ""
        self.x = 0.0
        self.y = 0.0
        self.scale_x = 1.0
        self.scale_y = 1.0
        self.rotation = 0.0          # degrees, clockwise (Flash convention)
        self.alpha = 1.0             # 0..1
        self.visible = True
        self.pivot_x = 0.0           # registration point
        self.pivot_y = 0.0
        self.parent = None
        self._world: _Matrix = _Matrix()

    # ------------------------------------------------------------- hierarchy
    @property
    def stage(self):
        o = self
        while o.parent is not None:
            o = o.parent
        return o

    # --------------------------------------------------------------- geometry
    def local_matrix(self) -> _Matrix:
        r = math.radians(self.rotation)
        cos_t, sin_t = math.cos(r), math.sin(r)
        a = cos_t * self.scale_x
        b = -sin_t * self.scale_y
        c = sin_t * self.scale_x
        d = cos_t * self.scale_y
        tx = self.x - (a * self.pivot_x + b * self.pivot_y)
        ty = self.y - (c * self.pivot_x + d * self.pivot_y)
        return _Matrix(a, b, c, d, tx, ty)

    def _world_matrix(self) -> _Matrix:
        chain = []
        o = self
        while o is not None:
            chain.append(o)
            o = o.parent
        m = _Matrix()
        for o in reversed(chain):
            m = m.multiply(o.local_matrix())
        return m

    def get_bounds(self):
        """Local content bounds ``(min_x, min_y, max_x, max_y)`` or None."""
        return None

    @property
    def width(self) -> float:
        b = self.get_bounds()
        return 0.0 if b is None else (b[2] - b[0]) * abs(self.scale_x)

    @width.setter
    def width(self, value: float):
        b = self.get_bounds()
        if b is not None and b[2] - b[0] > 1e-6:
            self.scale_x = value / (b[2] - b[0])

    @property
    def height(self) -> float:
        b = self.get_bounds()
        return 0.0 if b is None else (b[3] - b[1]) * abs(self.scale_y)

    @height.setter
    def height(self, value: float):
        b = self.get_bounds()
        if b is not None and b[3] - b[1] > 1e-6:
            self.scale_y = value / (b[3] - b[1])

    def global_to_local(self, gx: float, gy: float):
        return self._world_matrix().apply_inverse(gx, gy)

    def local_to_global(self, lx: float, ly: float):
        return self._world_matrix().apply(lx, ly)

    def effective_alpha(self) -> float:
        a = 1.0
        o = self
        while o is not None:
            a *= o.alpha
            o = o.parent
        return a

    # ------------------------------------------------------------- hit tests
    def hit_test_point(self, gx: float, gy: float) -> bool:
        if not self.visible:
            return False
        lx, ly = self._world_matrix().apply_inverse(gx, gy)
        b = self.get_bounds()
        if b is None:
            return False
        return (b[0] - _ADJ) <= lx <= (b[2] + _ADJ) and \
               (b[1] - _ADJ) <= ly <= (b[3] + _ADJ)

    def hit_target(self, gx: float, gy: float):
        """Deepest visible object under the global point, or None."""
        return self if self.hit_test_point(gx, gy) else None

    # ---------------------------------------------------------------- events
    def dispatch_event(self, event: Event) -> None:
        if event.target is None:
            event.target = self
        self._emit(event)
        if event.bubbles:
            p = self.parent
            while p is not None:
                p._emit(event)
                p = p.parent

    # -------------------------------------------------------------- rendering
    def render(self, surface: pygame.Surface, parent_matrix: _Matrix) -> None:
        if not self.visible:
            return
        self._world = parent_matrix.multiply(self.local_matrix())
        self._render_self(surface, self._world)

    def _render_self(self, surface: pygame.Surface, world: _Matrix) -> None:
        pass


class DisplayObjectContainer(DisplayObject):
    """A display object that can hold children (rendered on top of each other,
    last child = front-most, just like ``addChild`` in Flash)."""

    def __init__(self):
        super().__init__()
        self._children: list = []

    # ------------------------------------------------------------- hierarchy
    @property
    def num_children(self) -> int:
        return len(self._children)

    def get_children(self) -> list:
        return list(self._children)

    def add_child(self, child: DisplayObject) -> DisplayObject:
        if child.parent is not None:
            child.parent.remove_child(child)
        if child is self:
            raise ValueError("Cannot add an object to itself")
        self._children.append(child)
        child.parent = self
        ev = Event(EventType.ADDED)
        ev.target = child
        child._emit(ev)
        return child

    def add_child_at(self, child: DisplayObject, index: int) -> DisplayObject:
        if child.parent is not None:
            child.parent.remove_child(child)
        index = max(0, min(index, len(self._children)))
        self._children.insert(index, child)
        child.parent = self
        ev = Event(EventType.ADDED)
        ev.target = child
        child._emit(ev)
        return child

    def remove_child(self, child: DisplayObject) -> DisplayObject:
        if child in self._children:
            self._children.remove(child)
            child.parent = None
            ev = Event(EventType.REMOVED)
            ev.target = child
            child._emit(ev)
        return child

    def remove_child_at(self, index: int) -> DisplayObject:
        child = self._children[index]
        return self.remove_child(child)

    def remove_all_children(self) -> None:
        for child in list(self._children):
            self.remove_child(child)

    def get_child_at(self, index: int) -> DisplayObject:
        return self._children[index]

    def get_child_by_name(self, name: str):
        for child in self._children:
            if child.name == name:
                return child
        return None

    def contains(self, child: DisplayObject) -> bool:
        o = child
        while o is not None:
            if o is self:
                return True
            o = o.parent
        return False

    def set_child_index(self, child: DisplayObject, index: int) -> None:
        if child not in self._children:
            return
        self._children.remove(child)
        index = max(0, min(index, len(self._children)))
        self._children.insert(index, child)

    def swap_children(self, a: DisplayObject, b: DisplayObject) -> None:
        if a in self._children and b in self._children:
            ia, ib = self._children.index(a), self._children.index(b)
            self._children[ia], self._children[ib] = b, a

    # --------------------------------------------------------------- geometry
    def get_bounds(self):
        boxes = []
        for c in self._children:
            if not c.visible:
                continue
            b = c.get_bounds()
            if b is None:
                continue
            m = c.local_matrix()
            corners = [m.apply(b[0], b[1]), m.apply(b[2], b[1]),
                       m.apply(b[2], b[3]), m.apply(b[0], b[3])]
            xs = [p[0] for p in corners]
            ys = [p[1] for p in corners]
            boxes.append((min(xs), min(ys), max(xs), max(ys)))
        if not boxes:
            return None
        return (min(b[0] for b in boxes), min(b[1] for b in boxes),
                max(b[2] for b in boxes), max(b[3] for b in boxes))

    def hit_test_point(self, gx: float, gy: float) -> bool:
        if not self.visible:
            return False
        return any(c.hit_test_point(gx, gy) for c in self._children)

    def hit_target(self, gx: float, gy: float):
        if not self.visible:
            return None
        for child in reversed(self._children):
            t = child.hit_target(gx, gy)
            if t is not None:
                return t
        return None

    # --------------------------------------------------------------- rendering
    def render(self, surface: pygame.Surface, parent_matrix: _Matrix) -> None:
        if not self.visible:
            return
        self._world = parent_matrix.multiply(self.local_matrix())
        self._render_self(surface, self._world)
        for child in self._children:
            child.render(surface, self._world)

    def _render_self(self, surface: pygame.Surface, world: _Matrix) -> None:
        pass


class Sprite(DisplayObjectContainer):
    """A container with a Flash-style ``graphics`` drawing surface."""

    def __init__(self):
        super().__init__()
        self.graphics = Graphics()

    def get_bounds(self):
        boxes = []
        gb = self.graphics.get_bounds()
        if gb is not None:
            boxes.append(gb)
        cb = super().get_bounds()
        if cb is not None:
            boxes.append(cb)
        if not boxes:
            return None
        return (min(b[0] for b in boxes), min(b[1] for b in boxes),
                max(b[2] for b in boxes), max(b[3] for b in boxes))

    def hit_target(self, gx: float, gy: float):
        if not self.visible:
            return None
        for child in reversed(self._children):
            t = child.hit_target(gx, gy)
            if t is not None:
                return t
        if self.graphics.get_bounds() is not None and self.hit_test_point(gx, gy):
            return self
        return None

    def hit_test_point(self, gx: float, gy: float) -> bool:
        if not self.visible:
            return False
        if super().hit_test_point(gx, gy):
            return True
        b = self.graphics.get_bounds()
        if b is None:
            return False
        lx, ly = self._world_matrix().apply_inverse(gx, gy)
        return (b[0] - _ADJ) <= lx <= (b[2] + _ADJ) and \
               (b[1] - _ADJ) <= ly <= (b[3] + _ADJ)

    def _render_self(self, surface: pygame.Surface, world: _Matrix) -> None:
        if not self.graphics._prims:
            return
        src, ox, oy = self.graphics.render()
        _blit_transformed(surface, src, (ox, oy), world,
                          self.effective_alpha(), self.graphics._tcache)


class Stage(DisplayObjectContainer):
    """The root display object with a fixed size -- the Flash document."""

    def __init__(self, width: int, height: int, screen: pygame.Surface,
                 bg_color=(255, 255, 255), fps: int = 30, caption: str = "flashpy"):
        super().__init__()
        self.name = "stage"
        self.stage_width = width
        self.stage_height = height
        self.screen = screen
        self.bg_color = bg_color
        self.fps = fps
        self.caption = caption
        self.frame = 0
        self.tweens = TweenManager()
        self.focus = None                 # focused input TextField
        self.keys = set()                 # currently held pygame key constants
        self.quit_on_escape = True
        self._quit = False
        self._mouse_target = None
        self._down_target = None
        self.show_origin = False

    # ----------------------------------------------------------------- tweens
    def add_tween(self, target, duration: int, **kwargs) -> Tween:
        return self.tweens.add(target, duration, **kwargs)

    def remove_tweens_of(self, target) -> None:
        self.tweens.remove_tweens_of(target)

    # ------------------------------------------------------------------- loop
    def quit(self):
        self._quit = True

    @property
    def quit_requested(self):
        return self._quit

    def tick(self):
        """Advance one frame: tweens -> enter_frame listeners -> timelines."""
        self.frame += 1
        self.tweens.update_all()
        ev = Event(EventType.ENTER_FRAME)
        stack = [self]
        while stack:
            obj = stack.pop()
            ev.target = obj
            obj._emit(ev)
            if isinstance(obj, DisplayObjectContainer):
                stack.extend(reversed(obj._children))
        from .movieclip import MovieClip  # local import avoids a cycle
        stack = [self]
        while stack:
            obj = stack.pop()
            if isinstance(obj, MovieClip):
                obj._tick_self()
            if isinstance(obj, DisplayObjectContainer):
                stack.extend(obj._children)

    def render(self) -> None:
        self.screen.fill(self.bg_color)
        super().render(self.screen, _Matrix())
        if self.show_origin:
            pygame.draw.circle(self.screen, (255, 0, 0), (0, 0), 4)

    # ----------------------------------------------------------------- events
    def handle_event(self, event) -> None:
        """Translate a pygame event into Flash-style display-list events."""
        if event.type == pygame.KEYDOWN:
            self.keys.add(event.key)
            if event.key == pygame.K_ESCAPE and self.quit_on_escape:
                self.quit()
                return
            if self.focus is not None:
                self.focus.handle_key(event)
                return
            ke = KeyboardEvent("key_down", key=event.key,
                               key_name=pygame.key.name(event.key),
                               unicode=getattr(event, "unicode", ""),
                               mods=event.mod)
            self.dispatch_event(ke)
        elif event.type == pygame.KEYUP:
            self.keys.discard(event.key)
            ke = KeyboardEvent("key_up", key=event.key,
                               key_name=pygame.key.name(event.key),
                               mods=event.mod)
            self.dispatch_event(ke)
        elif event.type in (pygame.MOUSEMOTION, pygame.MOUSEBUTTONDOWN,
                            pygame.MOUSEBUTTONUP):
            self._handle_mouse(event)

    def _handle_mouse(self, event) -> None:
        x, y = event.pos
        target = self.hit_target(x, y)

        if event.type == pygame.MOUSEMOTION:
            if target is not self._mouse_target:
                if self._mouse_target is not None:
                    self._mouse_target.dispatch_event(
                        MouseEvent("roll_out", x, y, target=self._mouse_target))
                if target is not None:
                    target.dispatch_event(MouseEvent("roll_over", x, y))
                self._mouse_target = target
            if target is not None:
                target.dispatch_event(MouseEvent("mouse_move", x, y))
        elif event.type == pygame.MOUSEBUTTONDOWN:
            self._down_target = target
            if target is not None:
                target.dispatch_event(MouseEvent("mouse_down", x, y,
                                                 button=event.button))
        elif event.type == pygame.MOUSEBUTTONUP:
            if target is not None:
                target.dispatch_event(MouseEvent("mouse_up", x, y,
                                                 button=event.button))
                if target is self._down_target:
                    target.dispatch_event(MouseEvent("click", x, y,
                                                     button=event.button))
            self._down_target = None


__all__ = ["DisplayObject", "DisplayObjectContainer", "Sprite", "Stage",
           "_Matrix", "_blit_transformed"]
