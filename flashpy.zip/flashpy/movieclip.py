"""flashpy.movieclip -- frame-based timelines, keyframes and motion tweens.

A ``MovieClip`` is a container with its own timeline, exactly like a Flash
symbol. Place children on keyframes, optionally attach a tween spec, and
the playhead interpolates everything for you::

    hero = MovieClip()
    kf1 = hero.add_keyframe(1)
    art.x, art.y = 0, 0
    kf1.add_child(art, name="art")

    kf2 = hero.add_keyframe(30, tween=TweenSpec(easing.Back.ease_out))
    art.x = 300                      # place where it should END UP
    kf2.add_child(art, name="art")

    hero.goto_and_play(1)            # art glides 0 -> 300 with overshoot

Capture order matters: set a child's transform *before* adding it to a
keyframe -- the keyframe snapshots its placement at that moment.
"""
from __future__ import annotations

from .display import DisplayObjectContainer
from .easing import Linear
from .events import Event, EventType


class TweenSpec:
    """Motion tween definition attached to a keyframe.

    ``rotate`` adds extra full clockwise turns across the tween span.
    """

    def __init__(self, easing=None, rotate: float = 0):
        self.easing = easing or Linear.ease_none
        self.rotate = float(rotate)


_SNAP_KEYS = ("x", "y", "rotation", "scale_x", "scale_y", "alpha")


def _snapshot(obj) -> dict:
    return {k: getattr(obj, k) for k in _SNAP_KEYS}


def _apply_snapshot(obj, props: dict) -> None:
    for k in _SNAP_KEYS:
        setattr(obj, k, props[k])


class Keyframe:
    """One frame of one layer. Children added here appear from this frame on."""

    def __init__(self, frame: int, layer: "Layer"):
        self.frame = int(frame)
        self.layer = layer
        self.children: list = []
        self.tween: TweenSpec = None
        self._props: dict = {}          # id(obj) -> placement snapshot

    def add_child(self, obj, name: str = None):
        """Place ``obj`` on this keyframe. Placement props are snapshotted
        NOW, so position the object before calling this."""
        if name:
            obj.name = name
        if obj not in self.children:
            self.children.append(obj)
        self._props[id(obj)] = _snapshot(obj)
        return obj

    def props_of(self, obj) -> dict:
        return self._props.get(id(obj)) or _snapshot(obj)

    def find_counterpart(self, obj):
        """The object in this keyframe representing ``obj`` in the previous
        keyframe (matched by identity, then by name)."""
        for c in self.children:
            if c is obj:
                return c
        if obj.name:
            for c in self.children:
                if c.name == obj.name:
                    return c
        return None


class Layer:
    """A timeline layer: an ordered list of keyframes."""

    def __init__(self, name: str = "Layer"):
        self.name = name
        self.keyframes: list = []       # sorted by frame

    def add_keyframe(self, frame: int, tween: TweenSpec = None) -> Keyframe:
        frame = max(1, int(frame))
        for kf in self.keyframes:
            if kf.frame == frame:
                if tween is not None:
                    kf.tween = tween
                return kf
        kf = Keyframe(frame, self)
        kf.tween = tween
        self.keyframes.append(kf)
        self.keyframes.sort(key=lambda k: k.frame)
        return kf

    def keyframe_at(self, frame: int):
        for kf in self.keyframes:
            if kf.frame == frame:
                return kf
        return None

    def active_at(self, frame: int):
        """The keyframe governing ``frame`` (last one with kf.frame <= frame)."""
        active = None
        for kf in self.keyframes:
            if kf.frame <= frame:
                active = kf
            else:
                break
        return active

    def next_after(self, kf: Keyframe):
        idx = self.keyframes.index(kf)
        if idx + 1 < len(self.keyframes):
            return self.keyframes[idx + 1]
        return None


class Timeline:
    """All layers of one MovieClip."""

    def __init__(self):
        self.layers: list = []

    def add_layer(self, name: str = None) -> Layer:
        layer = Layer(name or f"Layer {len(self.layers) + 1}")
        self.layers.append(layer)
        return layer

    def layer(self, index: int) -> Layer:
        while len(self.layers) <= index:
            self.add_layer()
        return self.layers[index]

    @property
    def total_frames(self) -> int:
        total = 1
        for layer in self.layers:
            for kf in layer.keyframes:
                total = max(total, kf.frame)
        return total

    # ------------------------------------------------------------- playhead
    def update(self, clip: "MovieClip", frame: int) -> None:
        """Sync ``clip``'s visible children (and tweens) to ``frame``."""
        for i, layer in enumerate(self.layers):
            kf = layer.active_at(frame)
            layer_keys = [k for k in clip._shown if k[0] == i]

            if kf is None:
                for k in layer_keys:
                    obj = clip._shown.pop(k)
                    clip._shown_kf.pop(k, None)
                    if obj.parent is clip:
                        clip.remove_child(obj)
                continue

            desired = {id(obj): obj for obj in kf.children}
            for k in layer_keys:
                if k[1] not in desired:
                    obj = clip._shown.pop(k)
                    clip._shown_kf.pop(k, None)
                    if obj.parent is clip:
                        clip.remove_child(obj)

            nxt = layer.next_after(kf)
            # The TweenSpec lives on the DESTINATION keyframe: it describes
            # how the playhead should arrive there.
            tweening = nxt is not None and nxt.tween is not None \
                and nxt.frame > kf.frame

            for obj in kf.children:
                key = (i, id(obj))
                first_show = key not in clip._shown
                prev_kf = clip._shown_kf.get(key)

                if first_show:
                    if obj.parent is not clip:
                        clip.add_child(obj)
                    clip._shown[key] = obj
                    clip._shown_kf[key] = kf
                    _apply_snapshot(obj, kf.props_of(obj))
                elif prev_kf is not kf:
                    clip._shown_kf[key] = kf
                    if not tweening and not clip._force_place:
                        _apply_snapshot(obj, kf.props_of(obj))

                if tweening:
                    end_obj = nxt.find_counterpart(obj)
                    if end_obj is not None:
                        span = nxt.frame - kf.frame
                        t = max(0.0, min(1.0, (frame - kf.frame) / span))
                        e = nxt.tween.easing(t)
                        s = kf.props_of(obj)
                        en = nxt.props_of(end_obj)
                        obj.x = s["x"] + (en["x"] - s["x"]) * e
                        obj.y = s["y"] + (en["y"] - s["y"]) * e
                        obj.rotation = (s["rotation"]
                                        + (en["rotation"] - s["rotation"]) * e
                                        + nxt.tween.rotate * 360.0 * e)
                        obj.scale_x = s["scale_x"] + (en["scale_x"] - s["scale_x"]) * e
                        obj.scale_y = s["scale_y"] + (en["scale_y"] - s["scale_y"]) * e
                        obj.alpha = s["alpha"] + (en["alpha"] - s["alpha"]) * e
        clip._force_place = False


class MovieClip(DisplayObjectContainer):
    """A display container with its own timeline -- the heart of Flash."""

    def __init__(self):
        super().__init__()
        self._timeline = Timeline()
        self.current_frame = 1
        self.playing = True
        self.loop = True
        self._shown: dict = {}          # (layer_idx, id(obj)) -> obj
        self._shown_kf: dict = {}       # (layer_idx, id(obj)) -> keyframe
        self._frame_scripts: dict = {}  # frame -> [callbacks]
        self._timeline_initialized = False
        self._force_place = False

    # ------------------------------------------------------------- timeline
    @property
    def timeline(self) -> Timeline:
        return self._timeline

    @property
    def total_frames(self) -> int:
        return self._timeline.total_frames

    def add_layer(self, name: str = None) -> Layer:
        return self._timeline.add_layer(name)

    def layer(self, index: int) -> Layer:
        return self._timeline.layer(index)

    def add_keyframe(self, frame: int, layer: int = 0,
                     tween: TweenSpec = None) -> Keyframe:
        return self._timeline.layer(layer).add_keyframe(frame, tween)

    def on_frame(self, frame: int, callback) -> None:
        """Frame script: runs every time the playhead enters ``frame``."""
        self._frame_scripts.setdefault(int(frame), []).append(callback)

    # ------------------------------------------------------------ transport
    def play(self) -> None:
        self.playing = True

    def stop(self) -> None:
        self.playing = False

    def goto_and_play(self, frame: int) -> None:
        self.current_frame = max(1, min(int(frame), self._timeline.total_frames))
        self._force_place = True
        self.playing = True
        self._apply_frame()

    def goto_and_stop(self, frame: int) -> None:
        self.current_frame = max(1, min(int(frame), self._timeline.total_frames))
        self._force_place = True
        self.playing = False
        self._apply_frame()

    def next_frame(self) -> None:
        self.goto_and_stop(self.current_frame + 1)

    def prev_frame(self) -> None:
        self.goto_and_stop(self.current_frame - 1)

    # ----------------------------------------------------------------- tick
    def _ensure_timeline(self) -> None:
        if not self._timeline_initialized:
            self._apply_frame()
            self._timeline_initialized = True

    def _apply_frame(self) -> None:
        self._timeline.update(self, self.current_frame)
        for cb in list(self._frame_scripts.get(self.current_frame, ())):
            cb()

    def _tick_self(self) -> None:
        if self.playing:
            total = self._timeline.total_frames
            if total > 1:
                self.current_frame += 1
                if self.current_frame > total:
                    if self.loop:
                        self.current_frame = 1
                    else:
                        self.current_frame = total
                        self.playing = False
                        self.dispatch_event(Event(EventType.COMPLETE))
                self._apply_frame()
            else:
                self._timeline_initialized = True
        else:
            self._ensure_timeline()

    def render(self, surface, parent_matrix) -> None:
        if not self.visible:
            return
        self._ensure_timeline()
        super().render(surface, parent_matrix)


__all__ = ["MovieClip", "Timeline", "Layer", "Keyframe", "TweenSpec"]
